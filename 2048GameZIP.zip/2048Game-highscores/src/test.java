import javax.swing.*;

public class test {
    private JPanel pan;
    private JLabel label;
}
